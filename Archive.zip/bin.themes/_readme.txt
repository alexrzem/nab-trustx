not automated scripts - purtely 'export' and 'import'


